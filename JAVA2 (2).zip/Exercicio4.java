public class Exercicio4 {
    public static void main(String[] args) {
        int preço = 17;
        String valor = 50.5;

        System.out.println(preço); // vai imprimir "17"
        System.out.println(valor);// vai imprimir o nome escrito na variável
    }
}