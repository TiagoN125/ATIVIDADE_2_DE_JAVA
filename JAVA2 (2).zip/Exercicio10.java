public class Exercicio10 {
    public static void main(String[] args) {
        Scanner pudim = new Scanner(System.in);
        
        System.out.println("Digite um número: ");
        double raio = pudim.nextInt();

        if (raio % 2 == 0) {
            System.out.println("Ele e par" );
        } else 
        {System.out.println("Ele e ímpar:" );
    }
    }
}