public class Exercicio7 {
    public static void main (String[] args) {
         int a = 2;
         int b = 5;

         int soma;

         soma = (a + b);

         System.out.println("A soma dos dois numeros é: " + soma);
    }
}
