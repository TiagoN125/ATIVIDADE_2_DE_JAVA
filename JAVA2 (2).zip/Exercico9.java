public class Exercico9 {
    public static void main(String[] args) {
        double raio = 0

        raio = 5.0;

        double area = Math.PI * Math.pow(raio, b:2);


        double perimetro = 2 * Math.PI * raio;

        System.out.println("A area do circulo é: " + area);
        System.out.println("O perimetro do circulo é: " + perimetro);

    }
}