public class Exercicio6 {
    public static void main(String[] args) {
        int num1 = 16;
        int num2 = 32;
        int num3 = 48;

        float media = (num1 + num2 + num3) / 3;

        System.out.println("A media dos tres numeros e: " + media);
    }
}