public class Exercicio2 {
    public static void main(String[] args) {
      int idade = 20; // imprime a idade.
      System.out.println(idade);

      int idadeNoAnoQueVem; // gera uma idade no ano seguinte.
      idadeNoAnoQueVem = idade + 1;

      System.out.println(idadeNoAnoQueVem); // imprime a idade.

  }
}