public class Exercicio3 {
    public static void main(String[] args) {
        int idade = 17;
        String nome = "Vitor";

        System.out.println(idade); // vai imprimir "17"
        System.out.println(nome);// vai imprimir o nome escrito na variável
    }
}